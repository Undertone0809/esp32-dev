C
^

Image from variable and symbol 
"""""""""""""""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_img/lv_ex_img_1
  :language: c


Image recoloring 
""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_img/lv_ex_img_2
  :language: c


MicroPython
^^^^^^^^^^^

Image from variable and symbol 
"""""""""""""""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_img/lv_ex_img_1
  :language: py


Image recoloring 
""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_img/lv_ex_img_2
  :language: py
