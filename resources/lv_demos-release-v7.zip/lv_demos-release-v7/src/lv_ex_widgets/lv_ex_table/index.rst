C
^

Simple table 
"""""""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_table/lv_ex_table_1
  :language: c

MicroPython
^^^^^^^^^^^

Simple table 
"""""""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_table/lv_ex_table_1
  :language: py
