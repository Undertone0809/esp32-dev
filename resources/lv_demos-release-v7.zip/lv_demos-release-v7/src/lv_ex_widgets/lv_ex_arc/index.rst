C
^

Simple Arc 
""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_arc/lv_ex_arc_1
  :language: c

Loader with Arc 
""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_arc/lv_ex_arc_2
  :language: c

MicroPython
^^^^^^^^^^^

Simple Arc 
""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_arc/lv_ex_arc_1
  :language: py

Loader with Arc 
""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_arc/lv_ex_arc_2
  :language: py
