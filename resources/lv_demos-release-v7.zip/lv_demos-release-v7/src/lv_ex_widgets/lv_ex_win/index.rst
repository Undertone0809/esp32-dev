C
^

Simple window 
"""""""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_win/lv_ex_win_1
  :language: c

MicroPython
^^^^^^^^^^^

Simple window 
"""""""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_win/lv_ex_win_1
  :language: py
